using Microsoft.VisualStudio.TestTools.UnitTesting;
using Sortings;
using System;

namespace SortingUnitTests
{
    [TestClass]
    public class SortingTests
    {
        private int[] GenerateArray(int size, int minValue, int maxValue)
        {
            Random rand = new Random();
            int[] array = new int[size];
            for (int i = 0; i < array.Length; i++)
            {
                array[i] = rand.Next(minValue, maxValue);
            }
            return array;
        }

        private bool IsSorted(int[] array)
        {
            for (int i = 0; i < array.Length - 1; i++)
            {
                if (array[i] > array[i + 1])
                {
                    return false;
                }
            }
            return true;
        }

        private void ShowArray(int[] array)
        {
            for (int i = 0; i < array.Length; i++)
            {
                Console.Write(array[i] + " ");
            }
            Console.WriteLine();
        }

        public bool CheckSort(Action<int[]> sortFunc)
        {
            int[] A = GenerateArray(20, 1, 100);
            sortFunc(A);
            ShowArray(A);
            return IsSorted(A);
        }

        [TestMethod]
        public void TestBubbleSort()
        {
            bool res = CheckSort(Sorting.BubbleSort);
            Assert.IsTrue(res);
        }

        [TestMethod]
        public void TestMaxSort()
        {
            bool res = CheckSort(Sorting.MaxSort);
            Assert.IsTrue(res);
        }
    }
}
