﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sortings
{
    public static class Sorting
    {
        private static void Swap(int[] array, int i, int j)
        {
            int tmp = array[i];
            array[i] = array[j];
            array[j] = tmp;
        }

        private static void Bubble(int[] array, int startIndex, int endIndex)
        {
            for (int i = startIndex; i < endIndex; i++)
            {
                if (array[i] > array[i + 1])
                {
                    Swap(array, i, i + 1);
                }
            }
        }

        public static void BubbleSort(int[] array)
        {
            for (int k = array.Length - 1; k >= 0 ; k--)
            {
                Bubble(array, 0, k);
            }
        }

        private static int GetMax(int[] array, int startIndex, int endIndex)
        {
            int maxValue = array[0];
            int maxIndex = 0;
            for (int i = startIndex; i <= endIndex; i++)
            {
                if (array[i] > maxValue)
                {
                    maxValue = array[i];
                    maxIndex = i;
                }
            }
            return maxIndex;
        }

        public static void MaxSort(int[] array)
        {
            for (int k = array.Length - 1;  k >= 0;  k--)
            {
                int maxIndex = GetMax(array, 0, k);
                Swap(array, maxIndex, k);
            }
        }

        public static int[] Merge(int[] A, int[] B)
        {
            int[] C = new int[A.Length + B.Length];
            return C;
        }

        public static void MergeSort(int[] array)
        {
            void MergeSortAux(int[] arr)
            {

            }
            MergeSortAux(array);
        }

        public static int Select(int[] array , int k)
        {
            int index = -1;
            return index;
        }

        public static void Partition(int[] array, int pivot)
        {

        }

        public static void QuickSort(int[] array)
        {

        }

        public static void CountingSort(int[] array)
        {

        }

        public static void RadixSort(int[] array)
        {

        }

    }
}
